package com.ec.client.view;

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import com.ec.client.Client;

@SuppressWarnings("serial")
public class EditFile extends JFrame {
	//	private Files files;
	private static EditFile instance;
	private JPanel contentPane;
	private JTextField textField;
	private JTextArea textArea;

	public JTextArea getTextArea() {
		return textArea;
	}

	public void setTextArea(JTextArea textArea) {
		this.textArea = textArea;
	}

	/**
	 * Create the frame.
	 */
	public EditFile(int index, String nameFile, String content) {

		setTitle("EditorCompartilhado - Editar arquivo");
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JTextPane textPane = new JTextPane();
		contentPane.add(textPane, BorderLayout.CENTER);

		textField = new JTextField();
		textField.setEditable(false);
		contentPane.add(textField, BorderLayout.NORTH);
		textField.setColumns(10);
		textField.setText(nameFile);

		textArea = new javax.swing.JTextArea();
		textArea.setText(content);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);		
		contentPane.add(textArea);

		JScrollPane scroll = new JScrollPane(textArea); 
		contentPane.add(scroll);

		textArea.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent e) {
				if(e.getKeyChar() == KeyEvent.VK_ENTER){
				}
				new Thread( new Runnable() {
					@Override
					public void run() {
						try{
							Client.getStub().getFiles().getDirFiles().get(index - 1).setContentString(textArea.getText());					
							textArea.setCaretPosition(textArea.getDocument().getLength());
							TimeUnit.SECONDS.sleep(3);
						}catch (Exception e) {
							System.out.println(e.getMessage());
						}
					}

				}).start();
			}
		});



		Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate( new Runnable() {
			@Override
			public void run() {
				try{
					textArea.setText(Client.getStub().getFiles().getDirFiles().get(index - 1).getContentString());
					textArea.setCaretPosition(textArea.getDocument().getLength());
				}catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
		},0,3, TimeUnit.SECONDS);

		EditFile.instance = this;
	}

	public static EditFile getInstance() {
		return instance;
	}
}

