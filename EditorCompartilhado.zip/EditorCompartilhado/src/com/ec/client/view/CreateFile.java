package com.ec.client.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.ec.client.Client;
import com.ec.server.model.Files;

public class CreateFile extends JDialog {
	private static final long serialVersionUID = -2681607921401615463L;
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	
	private static CreateFile instance;
	
	/**
	 * Create the dialog.
	 */
	public CreateFile(Files files) {
		setTitle("Criar novo arquivo");
		setBounds(100, 100, 387, 128);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JLabel lblNomeDoArquivo = new JLabel("Nome do arquivo:");
			contentPanel.add(lblNomeDoArquivo);
		}
		{
			textField = new JTextField();
			contentPanel.add(textField);
			textField.setColumns(22);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Salvar");
				okButton.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent arg0) {
						dispose();
						files.addFile(textField.getText());
						try{
							Files filesAux = Client.getStub().getFiles();
							filesAux.refresh();
							FileList.getInstance().refresh();
							FileList.getInstance().setVisible(true);
						}catch (Exception e) {
							// TODO: handle exception
						}
					}
				});
				okButton.setActionCommand("SAVE");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent arg0) {
						dispose();
						try{
							FileList.getInstance().refresh();
							FileList.getInstance().setVisible(true);
						}catch (Exception e) {
							// TODO: handle exception
						}
					}
				});
				cancelButton.setActionCommand("CANC");
				buttonPane.add(cancelButton);
			}
		}
		instance = this;
	}
	
	public static CreateFile getInstance() {
		return instance;
	}
}
