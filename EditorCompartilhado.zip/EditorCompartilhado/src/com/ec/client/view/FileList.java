package com.ec.client.view;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.border.EmptyBorder;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import com.ec.client.Client;
import com.ec.server.model.Files;

public class FileList extends JFrame{
	private static final long serialVersionUID = 5511913240464045850L;
	private JPanel contentPane;
	private static FileList instance;
	private JTree tree;
	private Files files;

	public FileList() {
		try{
			this.files = Client.getStub().getFiles();
		}catch (Exception e) {
			// TODO: handle exception
		}
		setTitle("EditorCompartilhado - Arquivos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		tree = new JTree();
		tree.setModel(new DefaultTreeModel(
				new DefaultMutableTreeNode("Arquivos") {
					private static final long serialVersionUID = 9094436724320860627L;
					{	
						for(int i=0; i < files.getDirFiles().size(); i++){
							add(new DefaultMutableTreeNode(files.getDirFiles().get(i).getFileName()));
						}
					}
				}
				));

		tree.addMouseListener(new MouseAdapter(){
			@Override 
			public void mousePressed(MouseEvent e) {
				int selRow = tree.getRowForLocation(e.getX(), e.getY());
				TreePath selPath = tree.getPathForLocation(e.getX(), e.getY());
				if (selRow != -1 && e.getClickCount() == 2 && selPath != null) {
					try{
						new EditFile(selRow, files.getDirFiles().get(selRow - 1).getFileName(), files.getDirFiles().get(selRow - 1).getContentString()).setVisible(true);
					}catch(Exception ex){
						System.out.println("Error: " + ex.getMessage());
					}
				}
			} 
		});
		
		JScrollPane scrollTree = new JScrollPane(tree);
		scrollTree.setViewportView(tree);
		
		contentPane.add(scrollTree, BorderLayout.CENTER);

		JToolBar toolBar = new JToolBar();
		contentPane.add(toolBar, BorderLayout.NORTH);
		
		JButton btnNovoArquivo = new JButton("Novo arquivo");
		btnNovoArquivo.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {
				dispose();
				new CreateFile(files).setVisible(true);
			}
		});
		toolBar.add(btnNovoArquivo);

		JButton btnExcluirArquivo = new JButton("Excluir arquivo");
		btnExcluirArquivo.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {
				int[] selRow = tree.getSelectionRows();
		        for(int i=0; i < selRow.length; i++){
		          files.removeFile(files.getDirFiles().get(selRow[i] - 1).getFileName());
		        }
		        FileList.getInstance().refresh();
			}
		});
		toolBar.add(btnExcluirArquivo);
		FileList.instance = this;
	}

	public void refresh(){
		try{
			Files filesaux = Client.getStub().getFiles();
			filesaux.refresh();
			this.files = filesaux;
		}catch (Exception e) {
			// TODO: handle exception
		}

		tree.setModel(new DefaultTreeModel(
				new DefaultMutableTreeNode("Arquivos") {
					private static final long serialVersionUID = 9094436724320860627L;
					{	
						for(int i=0; i < files.getDirFiles().size(); i++){
							add(new DefaultMutableTreeNode(files.getDirFiles().get(i).getFileName()));
						}
					}
				}
				));
		DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
		model.reload();
	}

	public static FileList getInstance() {
		return instance;
	}
}
