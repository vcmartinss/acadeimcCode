package com.ec.client;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

import com.ec.client.view.FileList;
import com.ec.server.ServerInterface;

public class Client {

	public static ServerInterface getStub(){
		String host = null;
		ServerInterface stub = null;
		try{
			stub = (ServerInterface) LocateRegistry.getRegistry(host).lookup("ECV1");
		}catch(NotBoundException nbex){
			System.out.println("Error bind object: " + nbex.getMessage());
		}catch(RemoteException rex){
			System.out.println("Error called remote: " + rex.getMessage());
		}catch(Exception e){
			System.out.println("Error: " + e.getMessage());
		}

		return stub;
	}
	public static void main(String[] args) {
		new FileList().setVisible(true);	
	}
}
