package com.ec.server.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Serializable;

public class FileUtil implements Serializable{
	private static final long serialVersionUID = -6099332416239748517L;
	private File file;
	private String fileName;
	private String content;
	
	public FileUtil(File file){
		this.fileName = file.getName();
		this.file = file;
	}
	
	public FileUtil(String fileName) {
		super();
		this.fileName = fileName;
		this.file = new File(fileName);
		try {
			if(!this.file.exists())
				this.file.createNewFile();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public String getFileName() {
		return fileName;
	}

	public File getFile() {
		return file;
	}
	
	public String getContentString(){
		FileReader reader;
				
		try {
			reader = new FileReader(this.file);

			this.content = "";
			
			int line = reader.read();
			while (line != -1) {
                this.content += (char) line;
                line = reader.read();
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return this.content;
	}
	
	public void setContentString(String content){
		this.content = content;
		save();
	}
	
	public void save(){
		FileWriter writer;
		BufferedWriter buffer;
		
		try {
			writer = new FileWriter(this.file);
			buffer = new BufferedWriter(writer);
			buffer.write(this.content);
			buffer.flush();
			buffer.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void removeFile(){
	    this.file.delete();
	}
}
