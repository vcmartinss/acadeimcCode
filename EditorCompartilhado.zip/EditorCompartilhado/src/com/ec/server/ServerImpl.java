package com.ec.server;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

import com.ec.server.model.Files;

public class ServerImpl implements ServerInterface{

	private Files files;

	public ServerImpl(Files files) {
		super();
		this.files = files;
	}

	public Files getFiles() throws RemoteException{
		return this.files;
	}

	public static void main(String[] args) {

		try{
			String baseDir = "C:/Users/GFX/Desktop/files";
			Files files = new Files(baseDir);	
			
			ServerInterface stub = (ServerInterface) UnicastRemoteObject.exportObject(new ServerImpl(files), 0);
			LocateRegistry.getRegistry().rebind("ECV1", stub);
			
			System.out.println("Server running...");
			
		}catch (Exception e) {
			System.out.println("Error - " + e.getMessage());
			e.printStackTrace();
		}
	}
}
