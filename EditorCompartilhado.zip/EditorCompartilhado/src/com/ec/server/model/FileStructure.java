package com.ec.server.model;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

import com.ec.server.util.FileUtil;

public class FileStructure implements Serializable{ 
	private static final long serialVersionUID = 6754133681370940526L;
	private UUID id;
	private FileUtil file;
	
	public FileStructure(String fileName){
		this.id = UUID.randomUUID();
		this.file = new FileUtil(fileName);
	}
	
	public UUID getId() {
		return id;
	}

	public String getFileName() {
		return this.file.getFileName();
	}
	
	public FileUtil getFile() {
		return file;
	}
	
	public boolean equals(Object o) {
		if (this == o)
			return true;

		if (o == null)
			return false;

		if (this.getClass() != o.getClass())
			return false;
		
		FileStructure file = (FileStructure) o;
		return Objects.equals(this.id, file.id);
	}
	
}
