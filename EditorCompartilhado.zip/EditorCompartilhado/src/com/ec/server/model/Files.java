package com.ec.server.model;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

import com.ec.server.util.FileUtil;

public class Files implements Serializable{
	private static final long serialVersionUID = 8103915832722356920L;
	private String dir;
	private File fileDir;
	private ArrayList<FileUtil> dirFiles;
	
	public Files(String dir){
		this.fileDir = new File(dir);
		this.dir = fileDir.getAbsolutePath();
		this.dirFiles = new ArrayList<FileUtil>();
		try {
			if(this.fileDir.isDirectory()) {
				File[] listFiles = this.fileDir.listFiles();
				for (File file : listFiles) {
					if(file.isFile())
						this.dirFiles.add(new FileUtil(file));
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public String getDir() {
		return dir;
	}
	
	public ArrayList<FileUtil> getDirFiles() {		
		return dirFiles;
	}

	public void addFile(String fileName){
		dirFiles.add(new FileUtil(this.dir + File.separatorChar + fileName));
	}
	
	public void refresh(){
		this.dirFiles = new ArrayList<FileUtil>();
		try {
			if(this.fileDir.isDirectory()) {
				File[] listFiles = this.fileDir.listFiles();
				for (File file : listFiles) {
					if(file.isFile())
						this.dirFiles.add(new FileUtil(file));
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void removeFile(String fileName){
	    new FileUtil(this.dir + File.separatorChar + fileName).removeFile();
	}
}
