package com.ec.server;

import java.rmi.Remote;
import java.rmi.RemoteException;

import com.ec.server.model.Files;

public interface ServerInterface extends Remote{
	public Files getFiles() throws RemoteException;
}
